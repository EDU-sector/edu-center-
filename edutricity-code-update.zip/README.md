# EduTricity 🎓

**Education discovery and comparison for Chandigarh, Mohali, and Panchkula.**

EduTricity is a PHP + MySQL web application for discovering educational institutions, filtering listings, comparing selected institutions, and suggesting missing records.

## UI Direction

![EduTricity homepage design reference](docs/images/platform-preview.png)

The image is the intended visual direction, not a screenshot of the running application. The implementation uses server-rendered PHP and database-backed records; institution names, fee ranges, and official websites must come from the database and be verified before use.

## Features

- Responsive education-discovery homepage inspired by the EduTricity wireframe
- Search by institution name, location, category, and description
- Filters for location, education sector, and ownership
- Database-driven category cards and platform metrics
- Institution cards with fee ranges and available official website links
- Select up to three institutions for side-by-side comparison
- Dark/light theme toggle with local preference persistence
- FAQ, location discovery, and institution suggestion form
- PDO prepared statements, escaped output, and CSRF protection for suggestions

## Technology Stack

- HTML5 and CSS3
- Vanilla JavaScript
- PHP with PDO
- MySQL / MariaDB
- Git and GitHub for collaboration

This project does **not** include a chatbot or AI service.

## Repository Layout

```text
edu-center-/
├── app/db.php
├── database/schema.sql
├── includes/header.php
├── includes/footer.php
├── public/
│   ├── index.php
│   ├── process-suggestion.php
│   └── assets/
│       ├── css/style.css
│       └── js/app.js
├── scripts/init-db.php
├── index.php
├── process-suggestion.php
├── README.md
└── docs/architecture.md
```

## Local Setup

1. Install PHP with PDO MySQL support and a MySQL/MariaDB server.
2. Create or configure the `edutricity` database.
3. Set the environment variables for the database connection:

   ```bash
   export DB_HOST=127.0.0.1
   export DB_PORT=3306
   export DB_NAME=edutricity
   export DB_USER=your_database_user
   export DB_PASS=your_database_password
   export DB_CHARSET=utf8mb4
   ```

4. If the database is new, review `database/schema.sql` before running the setup script. Do not re-run initialization against a database containing important data unless you have confirmed the script is safe for it.
5. Start PHP with `public/` as the document root:

   ```bash
   php -S 0.0.0.0:8000 -t public
   ```

6. Open the forwarded port 8000 in your browser.

In Codespaces, the known PHP executable with MySQL PDO support is `/usr/bin/php8.3`:

```bash
/usr/bin/php8.3 -S 0.0.0.0:8000 -t public
```

The homepage uses a graceful error state when the database is unavailable. Institution sample data and fee values must be verified against official sources before being treated as authoritative.

## Testing

Run PHP syntax checks on the changed server-side files:

```bash
php -l public/index.php
php -l includes/header.php
php -l includes/footer.php
php -l app/db.php
php -l public/process-suggestion.php
```

Also test search/filter forms, selection of up to three institutions, comparison removal, suggestion validation and database insertion, dark/light mode, and mobile layout in the browser.

## Project Status

The PHP + MySQL discovery website is being refined. Check the implementation and repository issues for the current status of individual features.
