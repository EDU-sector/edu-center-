# Apply this EduTricity update

This is an **overlay patch**, not a replacement repository. Extract these files into the root of the existing `edu-center-` repository, preserving existing files not included here.

## Files included

- `public/index.php` — refreshed dashboard homepage, database-backed filters, institution cards, and selectable comparison
- `public/assets/css/style.css` — responsive UI based on the supplied EduTricity mockup
- `public/assets/js/app.js` — theme toggle, comparison limit/count, ownership tabs, and sign-in placeholder feedback
- `public/process-suggestion.php` — suggestion validation, CSRF verification, prepared insert, and correct redirects
- `includes/header.php` and `includes/footer.php` — shared header/footer, robust asset paths, and responsive navigation
- `app/db.php` — safer logging and generic connection errors
- `README.md` — corrected PHP/MySQL project description and UI preview
- `package.json` — PHP development and lint commands
- `docs/images/platform-preview.png` — the supplied intended UI reference

## Apply in GitHub Codespaces

1. Ensure the current work is committed or otherwise backed up before replacing files.
2. Extract/drag these files into `/workspaces/edu-center-`, preserving the folder paths and allowing replacement of the listed files.
3. Review the diff with `git status` and `git diff`.
4. Run the checks below before committing.

```bash
php -l public/index.php
php -l includes/header.php
php -l includes/footer.php
php -l app/db.php
php -l public/process-suggestion.php
node --check public/assets/js/app.js
```

If `/usr/bin/php8.3` is the working PHP runtime in the Codespace, use that executable for all PHP checks and for starting the server:

```bash
/usr/bin/php8.3 -S 0.0.0.0:8000 -t public
```

Do not run `scripts/init-db.php` against a database containing important data just to test the visual update. This update does not require a schema reset.

## Git workflow

Review the changed files, then commit on a feature branch and open a pull request into `main`. Do not force-push or reset existing work.
