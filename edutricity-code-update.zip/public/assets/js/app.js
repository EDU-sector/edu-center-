document.addEventListener('DOMContentLoaded', () => {
  const root = document.documentElement;
  const themeToggle = document.querySelector('.theme-toggle');
  const toast = document.querySelector('#site-toast');
  let toastTimer;

  const showToast = (message) => {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('visible');
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove('visible'), 3200);
  };

  const applyTheme = (theme) => {
    const next = theme === 'dark' ? 'dark' : 'light';
    root.setAttribute('data-theme', next);
    if (themeToggle) {
      const icon = themeToggle.querySelector('.theme-toggle-icon');
      if (icon) icon.textContent = next === 'dark' ? '☾' : '☼';
      themeToggle.setAttribute('aria-label', next === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
      themeToggle.setAttribute('title', next === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
    }
    const themeColor = document.querySelector('meta[name="theme-color"]');
    if (themeColor) themeColor.setAttribute('content', next === 'dark' ? '#0d1423' : '#f7faff');
  };

  let storedTheme = 'light';
  try {
    storedTheme = localStorage.getItem('edutricity-theme') || 'light';
  } catch (error) {
    // Theme persistence is optional when browser storage is unavailable.
  }
  applyTheme(storedTheme);

  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      applyTheme(next);
      try {
        localStorage.setItem('edutricity-theme', next);
      } catch (error) {
        showToast('Theme changed. This browser could not save the preference.');
      }
    });
  }

  const comparisonForm = document.querySelector('#compare-selection-form');
  const compareChecks = [...document.querySelectorAll('[data-compare-check]')];
  const headerCount = document.querySelector('[data-compare-header-count]');
  const compareCountLabels = [...document.querySelectorAll('.compare-count')];
  const hiddenCompareIds = [...document.querySelectorAll('[data-hidden-compare-id]')];
  const feedback = document.querySelector('#compare-feedback');
  const maxComparisons = 3;

  const updateCompareCount = () => {
    const count = hiddenCompareIds.length + compareChecks.filter((checkbox) => checkbox.checked).length;
    if (headerCount) headerCount.textContent = `${count}/3`;
    compareCountLabels.forEach((label) => { label.textContent = `(${count}/3)`; });
    compareChecks.forEach((checkbox) => {
      const label = checkbox.closest('label');
      const text = label?.querySelector('span');
      if (text) text.textContent = checkbox.checked ? 'Selected for comparison' : 'Add to compare';
      if (!checkbox.checked && count >= maxComparisons) {
        checkbox.setAttribute('aria-disabled', 'true');
      } else {
        checkbox.removeAttribute('aria-disabled');
      }
    });
  };

  compareChecks.forEach((checkbox) => {
    checkbox.addEventListener('change', () => {
      const selectedCount = hiddenCompareIds.length + compareChecks.filter((item) => item.checked).length;
      if (checkbox.checked && selectedCount > maxComparisons) {
        checkbox.checked = false;
        if (feedback) feedback.textContent = 'You can compare up to three institutions at a time. Remove one selection first.';
        showToast('Choose up to three institutions for comparison.');
      } else if (feedback) {
        feedback.textContent = '';
      }
      updateCompareCount();
    });
  });

  if (comparisonForm) {
    comparisonForm.addEventListener('submit', (event) => {
      const selected = compareChecks.filter((checkbox) => checkbox.checked);
      const totalSelected = hiddenCompareIds.length + selected.length;
      if (totalSelected > maxComparisons) {
        event.preventDefault();
        if (feedback) feedback.textContent = 'Choose no more than three institutions.';
        return;
      }
      if (totalSelected === 0) {
        event.preventDefault();
        if (feedback) feedback.textContent = 'Select at least one institution before opening the comparison.';
        showToast('Select an institution to begin comparing.');
      }
    });
  }
  if (comparisonForm) updateCompareCount();

  const ownershipTabs = [...document.querySelectorAll('[data-ownership-tab]')];
  const collegeCards = [...document.querySelectorAll('.college-card[data-ownership]')];
  const ownershipEmpty = document.querySelector('#ownership-empty');
  ownershipTabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      const filter = tab.dataset.ownershipTab;
      ownershipTabs.forEach((item) => {
        const active = item === tab;
        item.classList.toggle('active', active);
        item.setAttribute('aria-pressed', active ? 'true' : 'false');
      });
      let shown = 0;
      collegeCards.forEach((card) => {
        const visible = filter === 'all' || card.dataset.ownership === filter;
        card.hidden = !visible;
        if (visible) shown += 1;
      });
      if (ownershipEmpty) ownershipEmpty.hidden = shown !== 0;
    });
  });
  if (ownershipTabs.length) ownershipTabs[0].setAttribute('aria-pressed', 'true');

  const signInButton = document.querySelector('#sign-in-button');
  if (signInButton) {
    signInButton.addEventListener('click', () => showToast('Sign-in is not available yet. The directory can be explored without an account.'));
  }

  // Keep remote campus images from leaving a broken-image icon if a source is unavailable.
  document.querySelectorAll('img[src^="https://images.unsplash.com/"]').forEach((image) => {
    image.addEventListener('error', () => {
      image.hidden = true;
      if (image.parentElement) image.parentElement.classList.add('image-unavailable');
    }, { once: true });
  });
});
