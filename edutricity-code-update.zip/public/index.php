<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../app/db.php';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/footer.php';

$searchQuery = trim(is_string($_GET['q'] ?? null) ? $_GET['q'] : '');
$selectedCategory = trim(is_string($_GET['category'] ?? null) ? $_GET['category'] : '');
$selectedCity = trim(is_string($_GET['city'] ?? null) ? $_GET['city'] : '');
$selectedOwnership = trim(is_string($_GET['ownership'] ?? null) ? $_GET['ownership'] : '');
$allowedOwnerships = ['Private', 'Government', 'Public', 'Semi-Government'];
if (!in_array($selectedOwnership, $allowedOwnerships, true)) {
    $selectedOwnership = '';
}

$rawCompareIds = $_GET['compare'] ?? [];
if (!is_array($rawCompareIds)) {
    $rawCompareIds = [];
}
$compareIds = array_values(array_unique(array_filter(
    array_map(static fn ($id): int => is_scalar($id) && filter_var((string) $id, FILTER_VALIDATE_INT) !== false ? (int) $id : 0, $rawCompareIds),
    static fn (int $id): bool => $id > 0
)));
$compareIds = array_slice($compareIds, 0, 3);

$showSuccess = isset($_GET['success']) && $_GET['success'] === '1';
$showError = isset($_GET['error']) && $_GET['error'] === '1';
$databaseAvailable = false;
$categories = [];
$cities = [];
$institutions = [];
$collegeInstitutions = [];
$compareInstitutions = [];
$metrics = ['institutions' => null, 'cities' => null, 'categories' => null];

try {
    $pdo = getDbConnection();
    $categories = $pdo->query('SELECT name FROM categories ORDER BY name ASC')->fetchAll(PDO::FETCH_COLUMN);
    $cities = $pdo->query('SELECT city FROM locations ORDER BY city ASC')->fetchAll(PDO::FETCH_COLUMN);

    $metrics['institutions'] = (int) $pdo->query('SELECT COUNT(*) FROM institutions')->fetchColumn();
    $metrics['cities'] = (int) $pdo->query('SELECT COUNT(*) FROM locations')->fetchColumn();
    $metrics['categories'] = (int) $pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn();

    if ($selectedCategory !== '' && !in_array($selectedCategory, $categories, true)) {
        $selectedCategory = '';
    }
    if ($selectedCity !== '' && !in_array($selectedCity, $cities, true)) {
        $selectedCity = '';
    }

    $where = [];
    $params = [];
    if ($searchQuery !== '') {
        $where[] = '(i.name LIKE :name_query OR l.city LIKE :city_query OR c.name LIKE :category_query OR i.description LIKE :description_query)';
        $like = '%' . $searchQuery . '%';
        $params[':name_query'] = $like;
        $params[':city_query'] = $like;
        $params[':category_query'] = $like;
        $params[':description_query'] = $like;
    }
    if ($selectedCategory !== '') {
        $where[] = 'c.name = :selected_category';
        $params[':selected_category'] = $selectedCategory;
    }
    if ($selectedCity !== '') {
        $where[] = 'l.city = :selected_city';
        $params[':selected_city'] = $selectedCity;
    }
    if ($selectedOwnership !== '') {
        $where[] = 'i.ownership = :selected_ownership';
        $params[':selected_ownership'] = $selectedOwnership;
    }

    $joins = ' FROM institutions i
               INNER JOIN locations l ON l.id = i.city_id
               INNER JOIN categories c ON c.id = i.category_id';
    $whereSql = $where === [] ? '' : ' WHERE ' . implode(' AND ', $where);

    $stmt = $pdo->prepare(
        'SELECT i.id, i.name, i.ownership, i.description, i.fee_range, i.website,
                l.city, c.name AS category'
        . $joins . $whereSql . ' ORDER BY i.name ASC LIMIT 100'
    );
    $stmt->execute($params);
    $institutions = $stmt->fetchAll();

    // The college showcase draws from actual College and University records only.
    $collegeInstitutions = $pdo->query(
        "SELECT i.id, i.name, i.ownership, i.description, i.fee_range, i.website,
                l.city, c.name AS category
         FROM institutions i
         INNER JOIN locations l ON l.id = i.city_id
         INNER JOIN categories c ON c.id = i.category_id
         WHERE c.name IN ('College', 'University')
         ORDER BY CASE WHEN c.name = 'College' THEN 0 ELSE 1 END, i.name ASC
         LIMIT 12"
    )->fetchAll();

    if ($compareIds !== []) {
        $placeholders = [];
        $compareParams = [];
        foreach ($compareIds as $index => $id) {
            $placeholder = ':compare_id_' . $index;
            $placeholders[] = $placeholder;
            $compareParams[$placeholder] = $id;
        }
        // The IDs are validated integers; FIELD preserves the user's selection order.
        $orderIds = implode(',', $compareIds);
        $compareStmt = $pdo->prepare(
            'SELECT i.id, i.name, i.ownership, i.description, i.fee_range, i.website,
                    l.city, c.name AS category'
            . $joins . ' WHERE i.id IN (' . implode(', ', $placeholders) . ')'
            . ' ORDER BY FIELD(i.id, ' . $orderIds . ')'
        );
        $compareStmt->execute($compareParams);
        $compareInstitutions = $compareStmt->fetchAll();
        $compareIds = array_map(static fn (array $row): int => (int) $row['id'], $compareInstitutions);
    }
    $databaseAvailable = true;
} catch (Throwable $e) {
    error_log('EduTricity homepage data error: ' . $e->getMessage());
}

$escape = static fn ($value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$safeWebsite = static function ($value): ?string {
    $url = trim((string) $value);
    if ($url === '' || filter_var($url, FILTER_VALIDATE_URL) === false) {
        return null;
    }
    $scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));
    $host = strtolower((string) parse_url($url, PHP_URL_HOST));
    if (!in_array($scheme, ['http', 'https'], true)) {
        return null;
    }
    // Do not present reserved example domains as institutional websites.
    if ($host === 'example.edu' || $host === 'example.com' || $host === 'example.org' || str_ends_with($host, '.example.edu') || str_ends_with($host, '.example.com') || str_ends_with($host, '.example.org')) {
        return null;
    }
    return $url;
};

$categoryInfo = [
    'School' => ['icon' => '⌂', 'class' => 'school', 'description' => 'School education and learning', 'image' => 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=900&q=82'],
    'College' => ['icon' => '▣', 'class' => 'college', 'description' => 'Undergraduate and diploma programmes', 'image' => 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=900&q=82'],
    'University' => ['icon' => '◆', 'class' => 'university', 'description' => 'Explore higher education', 'image' => 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=900&q=82'],
    'Coaching' => ['icon' => '▤', 'class' => 'coaching', 'description' => 'Exam preparation and tutoring', 'image' => 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=900&q=82'],
    'Skill Development' => ['icon' => '⚙', 'class' => 'skills', 'description' => 'Professional and practical skills', 'image' => 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=900&q=82'],
];
$defaultCategoryImage = 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=900&q=82';
$preservedFilters = array_filter([
    'q' => $searchQuery,
    'category' => $selectedCategory,
    'city' => $selectedCity,
    'ownership' => $selectedOwnership,
], static fn ($value): bool => $value !== '');
$filterQuery = $preservedFilters === [] ? '' : '?' . http_build_query($preservedFilters);
$visibleInstitutionIds = array_map(static fn (array $row): int => (int) $row['id'], $institutions);
$hiddenCompareIds = array_values(array_diff($compareIds, $visibleInstitutionIds));

$buildCompareUrl = static function (int $id, bool $remove = false) use ($compareIds, $preservedFilters): string {
    $ids = $compareIds;
    if ($remove) {
        $ids = array_values(array_filter($ids, static fn (int $existing): bool => $existing !== $id));
    } elseif (!in_array($id, $ids, true) && count($ids) < 3) {
        $ids[] = $id;
    }
    $query = $preservedFilters;
    if ($ids !== []) {
        $query['compare'] = $ids;
    }
    return '/index.php' . ($query === [] ? '' : '?' . http_build_query($query)) . '#compare';
};

$csrfToken = $_SESSION['edutricity_csrf_token'] ?? bin2hex(random_bytes(32));
$_SESSION['edutricity_csrf_token'] = $csrfToken;

renderHeader('EduTricity | Discover institutions across the Tricity', count($compareInstitutions));
?>

<div class="app-shell">
    <aside class="sidebar" aria-label="Information and navigation">
        <div class="sidebar-heading"><span class="sidebar-info-icon">i</span><span>Info</span></div>
        <nav class="sidebar-nav" aria-label="Page sections">
            <a href="#institutions"><span class="nav-icon trophy" aria-hidden="true">♜</span><span>Top Institutions</span></a>
            <a href="#institutions"><span class="nav-icon chart" aria-hidden="true">▥</span><span>Most Popular</span></a>
            <a href="#suggest"><span class="nav-icon plus" aria-hidden="true">⊕</span><span>Suggest an Institution</span></a>
            <a href="#faqs"><span class="nav-icon chat-icon" aria-hidden="true">▣</span><span>Contact Us / FAQs</span></a>
            <a href="#about"><span class="nav-icon people" aria-hidden="true">♧</span><span>About Us</span></a>
        </nav>
        <div class="sidebar-bottom">
            <p class="eyebrow">Discover locally</p>
            <p>One place to explore educational opportunities across the Tricity.</p>
            <div class="sidebar-location-links">
                <?php foreach (['Chandigarh', 'Mohali', 'Panchkula'] as $city): ?>
                    <a href="/index.php?<?= $escape(http_build_query(array_merge($preservedFilters, ['city' => $city]))); ?>#institutions"><?= $escape($city); ?><span aria-hidden="true">→</span></a>
                <?php endforeach; ?>
            </div>
        </div>
    </aside>

    <main class="page-main">
        <?php if (!$databaseAvailable): ?>
            <div class="flash error database-warning" role="alert">Institution data is temporarily unavailable. Please check the database connection and try again.</div>
        <?php endif; ?>

        <div class="dashboard-grid">
            <div class="dashboard-primary">
                <section class="hero" aria-labelledby="hero-title">
                    <div class="hero-overlay"></div>
                    <div class="hero-content">
                        <p class="hero-kicker">EDUCATION SECTOR</p>
                        <h1 id="hero-title"><?= $escape($selectedCity !== '' ? $selectedCity : 'Chandigarh'); ?></h1>
                        <p class="hero-subtitle">Schools · Colleges · Universities · Coaching · Skill Institutes</p>
                        <form class="hero-search" method="get" action="/index.php#institutions">
                            <label class="sr-only" for="hero-q">Search institutions, courses, or areas</label>
                            <span class="search-glass" aria-hidden="true">⌕</span>
                            <input id="hero-q" type="search" name="q" value="<?= $escape($searchQuery); ?>" placeholder="Search institutions, categories, or areas...">
                            <?php if ($selectedCity !== ''): ?><input type="hidden" name="city" value="<?= $escape($selectedCity); ?>"><?php endif; ?>
                            <?php if ($selectedCategory !== ''): ?><input type="hidden" name="category" value="<?= $escape($selectedCategory); ?>"><?php endif; ?>
                            <?php if ($selectedOwnership !== ''): ?><input type="hidden" name="ownership" value="<?= $escape($selectedOwnership); ?>"><?php endif; ?>
                            <button type="submit">Search</button>
                        </form>
                        <div class="hero-location-pills" aria-label="Choose a location">
                            <?php foreach (['Chandigarh', 'Mohali', 'Panchkula'] as $city): ?>
                                <a class="<?= ($selectedCity === $city || ($selectedCity === '' && $city === 'Chandigarh')) ? 'selected' : ''; ?>" href="/index.php?<?= $escape(http_build_query(array_merge($preservedFilters, ['city' => $city]))); ?>#institutions"><span aria-hidden="true">⌖</span> <?= $escape($city); ?></a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </section>

                <section class="sector-panel" aria-labelledby="sector-title">
                    <div class="panel-heading">
                        <div><h2 id="sector-title">Explore Education Sector</h2><p>Choose the kind of learning you're looking for.</p></div>
                        <a href="#institutions" class="text-link">View all <span aria-hidden="true">→</span></a>
                    </div>
                    <div class="sector-grid">
                        <?php
                        $sectorOrder = ['School', 'College', 'Coaching', 'Skill Development'];
                        foreach ($sectorOrder as $category):
                            if (!in_array($category, $categories, true)) {
                                continue;
                            }
                            $info = $categoryInfo[$category] ?? ['icon' => '◆', 'class' => 'default', 'description' => 'Explore available institutions', 'image' => $defaultCategoryImage];
                            ?>
                            <a class="sector-card" href="/index.php?<?= $escape(http_build_query(array_merge($preservedFilters, ['category' => $category]))); ?>#institutions">
                                <img src="<?= $escape($info['image']); ?>" alt="" loading="lazy" decoding="async">
                                <div class="sector-card-body"><span class="sector-icon <?= $escape($info['class']); ?>" aria-hidden="true"><?= $escape($info['icon']); ?></span><div><h3><?= $escape($category === 'Coaching' ? 'Coaching Institutes' : ($category === 'Skill Development' ? 'Skill & Professional' : ($category === 'School' ? 'School Education' : 'Colleges'))); ?></h3><p><?= $escape($info['description']); ?></p></div><span class="card-arrow" aria-hidden="true">›</span></div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </section>
            </div>

            <aside class="right-rail" aria-label="Quick actions">
                <section class="rail-panel compare-widget" aria-labelledby="quick-compare-title">
                    <div class="rail-title-row"><div class="rail-title-icon" aria-hidden="true">⚖</div><div class="rail-title-copy"><h2 id="quick-compare-title">Compare Institutions</h2><p>Select and compare colleges, fees, courses, facilities and more.</p></div><span class="compare-counter" data-compare-header-count><?= count($compareIds); ?>/3</span></div>
                    <?php if ($compareInstitutions === []): ?>
                        <div class="compare-empty-widget"><span class="document-icon" aria-hidden="true">▤</span><strong>No institutions added yet</strong><p>Browse institutions and select “Compare” on a card to add it here.</p></div>
                    <?php else: ?>
                        <div class="compare-widget-list">
                            <?php foreach ($compareInstitutions as $institution): ?>
                                <div class="compare-mini-row"><span class="mini-institution-icon" aria-hidden="true">◆</span><span><?= $escape($institution['name']); ?><small><?= $escape($institution['city']); ?> · <?= $escape($institution['category']); ?></small></span><a href="<?= $escape($buildCompareUrl((int) $institution['id'], true)); ?>" aria-label="Remove <?= $escape($institution['name']); ?> from comparison">×</a></div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <a class="widget-action <?= $compareInstitutions === [] ? 'disabled-look' : ''; ?>" href="#compare">View Comparison <span aria-hidden="true">→</span></a>
                </section>

                <section class="rail-panel nearby-widget" id="map" aria-labelledby="nearby-title">
                    <div class="rail-title-row"><div class="rail-title-icon" aria-hidden="true">⌖</div><div class="rail-title-copy"><h2 id="nearby-title">Near You</h2><p>Explore the Tricity region</p></div><a class="text-link" href="https://www.openstreetmap.org/search?query=Chandigarh%20Mohali%20Panchkula" target="_blank" rel="noopener noreferrer">View map →</a></div>
                    <div class="map-illustration" role="img" aria-label="Illustrated regional overview of Chandigarh, Mohali and Panchkula">
                        <span class="map-road road-one"></span><span class="map-road road-two"></span><span class="map-road road-three"></span>
                        <span class="map-river"></span>
                        <span class="map-marker marker-chandigarh"><i></i><b>Chandigarh</b></span>
                        <span class="map-marker marker-mohali"><i></i><b>Mohali</b></span>
                        <span class="map-marker marker-panchkula"><i></i><b>Panchkula</b></span>
                    </div>
                    <a class="map-search-link" href="https://www.openstreetmap.org/search?query=Chandigarh%20Mohali%20Panchkula" target="_blank" rel="noopener noreferrer">⌖ Search on Map</a>
                </section>
            </aside>
        </div>

        <section class="college-section" id="college-section" aria-labelledby="college-title">
            <div class="college-section-heading"><span class="college-section-mark" aria-hidden="true">⌂</span><div><h2 id="college-title">College Section</h2><p>Explore colleges and universities using available institution records.</p></div></div>
            <div class="ownership-tabs" role="group" aria-label="Filter institutions by ownership">
                <button type="button" class="ownership-tab active" data-ownership-tab="Private"><span aria-hidden="true">♜</span> Private</button>
                <button type="button" class="ownership-tab" data-ownership-tab="Government"><span aria-hidden="true">▤</span> Government</button>
                <button type="button" class="ownership-tab" data-ownership-tab="other"><span aria-hidden="true">↗</span> Public / Semi-Government</button>
            </div>
            <p class="demo-data-note">Institution information may require verification. Check official sources before making decisions.</p>
            <?php if (!$databaseAvailable || $collegeInstitutions === []): ?>
                <div class="empty-state compact-empty"><h3>No college records available yet</h3><p>Verified college and university records will appear here when available in the database.</p></div>
            <?php else: ?>
                <div class="college-cards" id="college-cards">
                    <?php foreach ($collegeInstitutions as $institution): ?>
                        <?php
                        $info = $categoryInfo[$institution['category']] ?? ['image' => $defaultCategoryImage, 'class' => 'default'];
                        $ownerBucket = in_array($institution['ownership'], ['Private'], true) ? 'Private' : (in_array($institution['ownership'], ['Government'], true) ? 'Government' : 'other');
                        $selectedForCompare = in_array((int) $institution['id'], $compareIds, true);
                        $website = $safeWebsite($institution['website'] ?? null);
                        ?>
                        <article class="college-card" data-ownership="<?= $escape($ownerBucket); ?>">
                            <div class="college-card-image"><img src="<?= $escape($info['image']); ?>" alt="Campus image for <?= $escape($institution['name']); ?>" loading="lazy" decoding="async"><span class="college-type-badge"><?= $escape($institution['category']); ?></span></div>
                            <div class="college-card-content"><h3><?= $escape($institution['name']); ?></h3><p class="college-location"><span aria-hidden="true">⌖</span> <?= $escape($institution['city']); ?></p><div class="college-tags"><span><?= $escape($institution['ownership']); ?></span><span><?= $escape($institution['category']); ?></span></div><p class="college-fee"><strong>Fee range</strong> <?= $escape($institution['fee_range'] ?: 'Not available'); ?></p><div class="college-card-links"><?php if ($website !== null): ?><a href="<?= $escape($website); ?>" target="_blank" rel="noopener noreferrer">Website ↗</a><?php else: ?><span>Website unverified</span><?php endif; ?></div>
                                <?php if ($selectedForCompare): ?><a class="add-compare-button selected" href="<?= $escape($buildCompareUrl((int) $institution['id'], true)); ?>">✓ Added · Remove</a><?php elseif (count($compareIds) >= 3): ?><span class="add-compare-button unavailable" title="Remove one institution from comparison before adding another">Comparison full (3/3)</span><?php else: ?><a class="add-compare-button" href="<?= $escape($buildCompareUrl((int) $institution['id'])); ?>">＋ Add to Compare</a><?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
                <p class="ownership-empty" id="ownership-empty" hidden>No institutions are listed for this ownership category yet.</p>
            <?php endif; ?>
        </section>

        <section class="comparison-section section-block" id="compare">
            <div class="panel-heading"><div><p class="eyebrow">Choose with clarity</p><h2>Compare Institutions</h2><p>Compare the records you selected. Missing information is shown as unavailable.</p></div><?php if ($compareInstitutions !== []): ?><a class="text-link" href="/index.php<?= $escape($filterQuery); ?>#institutions">Clear comparison ×</a><?php endif; ?></div>
            <?php if ($compareInstitutions === []): ?>
                <div class="empty-state comparison-empty"><span class="empty-icon" aria-hidden="true">⇄</span><h3>No institutions selected</h3><p>Use “Add to Compare” on a college card or select institutions in the catalogue below.</p><a href="#college-section" class="primary-btn">Choose institutions</a></div>
            <?php else: ?>
                <div class="comparison-summary"><p><strong><?= count($compareInstitutions); ?></strong> institution<?= count($compareInstitutions) === 1 ? '' : 's'; ?> selected (maximum 3).</p><?php if (count($compareInstitutions) < 2): ?><p class="muted-fact">Add one more institution to compare options side by side.</p><?php endif; ?></div>
                <div class="table-wrap"><table class="comparison-table"><thead><tr><th scope="col">Attribute</th><?php foreach ($compareInstitutions as $institution): ?><th scope="col"><span class="comparison-column-name"><?= $escape($institution['name']); ?></span><a class="remove-comparison" href="<?= $escape($buildCompareUrl((int) $institution['id'], true)); ?>">Remove ×</a></th><?php endforeach; ?></tr></thead><tbody>
                    <tr><th scope="row">Location</th><?php foreach ($compareInstitutions as $institution): ?><td><?= $escape($institution['city'] ?: 'Not available'); ?></td><?php endforeach; ?></tr>
                    <tr><th scope="row">Education sector</th><?php foreach ($compareInstitutions as $institution): ?><td><?= $escape($institution['category'] ?: 'Not available'); ?></td><?php endforeach; ?></tr>
                    <tr><th scope="row">Ownership</th><?php foreach ($compareInstitutions as $institution): ?><td><?= $escape($institution['ownership'] ?: 'Not available'); ?></td><?php endforeach; ?></tr>
                    <tr><th scope="row">Fee range</th><?php foreach ($compareInstitutions as $institution): ?><td><?= $escape($institution['fee_range'] ?: 'Not available'); ?></td><?php endforeach; ?></tr>
                    <tr><th scope="row">Overview</th><?php foreach ($compareInstitutions as $institution): ?><td><?= $escape($institution['description'] ?: 'Not available'); ?></td><?php endforeach; ?></tr>
                    <tr><th scope="row">Official website</th><?php foreach ($compareInstitutions as $institution): ?><?php $website = $safeWebsite($institution['website'] ?? null); ?><td><?php if ($website !== null): ?><a href="<?= $escape($website); ?>" target="_blank" rel="noopener noreferrer">Visit official website ↗</a><?php else: ?><span class="muted-fact">Not verified</span><?php endif; ?></td><?php endforeach; ?></tr>
                </tbody></table></div>
                <div class="comparison-footer"><p>Confirm fees, admissions, and other time-sensitive details with the institution.</p><a href="#institutions" class="ghost-btn">Add another institution</a></div>
            <?php endif; ?>
        </section>

        <section class="catalogue-section section-block" id="institutions">
            <div class="panel-heading">
                <div><p class="eyebrow">Browse the catalogue</p><h2>All institutions</h2><p>Filter database records by name, location, sector, and ownership.</p></div>
                <span class="catalogue-status"><?= $databaseAvailable ? 'Database catalogue' : 'Catalogue unavailable'; ?></span>
            </div>
            <form class="filter-bar" method="get" action="/index.php#institutions">
                <label><span>Search</span><input type="search" name="q" value="<?= $escape($searchQuery); ?>" placeholder="Institution, city or category"></label>
                <label><span>Location</span><select name="city"><option value="">All locations</option><?php foreach ($cities as $city): ?><option value="<?= $escape($city); ?>" <?= $selectedCity === $city ? 'selected' : ''; ?>><?= $escape($city); ?></option><?php endforeach; ?></select></label>
                <label><span>Sector</span><select name="category"><option value="">All sectors</option><?php foreach ($categories as $category): ?><option value="<?= $escape($category); ?>" <?= $selectedCategory === $category ? 'selected' : ''; ?>><?= $escape($category); ?></option><?php endforeach; ?></select></label>
                <label><span>Ownership</span><select name="ownership"><option value="">All types</option><?php foreach ($allowedOwnerships as $ownership): ?><option value="<?= $escape($ownership); ?>" <?= $selectedOwnership === $ownership ? 'selected' : ''; ?>><?= $escape($ownership); ?></option><?php endforeach; ?></select></label>
                <div class="filter-actions"><button class="primary-btn" type="submit">Apply filters</button><a class="ghost-btn" href="/index.php#institutions">Reset</a></div>
            </form>

            <?php if (!$databaseAvailable): ?>
                <div class="empty-state"><h3>Catalogue unavailable</h3><p>Institution records could not be loaded. Check the database configuration and reload this page.</p></div>
            <?php elseif ($institutions === []): ?>
                <div class="empty-state"><span class="empty-icon" aria-hidden="true">⌕</span><h3>No institutions found</h3><p>Try changing the search or clearing the filters.</p><a href="/index.php#institutions" class="primary-btn">Clear filters</a></div>
            <?php else: ?>
                <form id="compare-selection-form" method="get" action="/index.php#compare">
                    <?php foreach ($preservedFilters as $key => $value): ?><input type="hidden" name="<?= $escape($key); ?>" value="<?= $escape($value); ?>"><?php endforeach; ?>
                    <?php foreach ($hiddenCompareIds as $hiddenCompareId): ?><input type="hidden" name="compare[]" value="<?= (int) $hiddenCompareId; ?>" data-hidden-compare-id><?php endforeach; ?>
                    <div class="results-toolbar"><p class="result-count"><strong><?= count($institutions); ?></strong> matching record<?= count($institutions) === 1 ? '' : 's'; ?><?= $searchQuery !== '' ? ' for “' . $escape($searchQuery) . '”' : ''; ?></p><button type="submit" class="primary-btn">Compare selected <span class="compare-count">(<?= count($compareIds); ?>/3)</span></button></div>
                    <p class="form-feedback" id="compare-feedback" aria-live="polite"></p>
                    <div class="institution-grid">
                        <?php foreach ($institutions as $institution): ?>
                            <?php $website = $safeWebsite($institution['website'] ?? null); $isSelected = in_array((int) $institution['id'], $compareIds, true); $info = $categoryInfo[$institution['category']] ?? ['image' => $defaultCategoryImage, 'class' => 'default']; ?>
                            <article class="institution-card">
                                <div class="institution-image"><img src="<?= $escape($info['image']); ?>" alt="" loading="lazy" decoding="async"><span class="badge neutral"><?= $escape($institution['category']); ?></span></div>
                                <div class="institution-card-body"><div class="institution-card-title-row"><h3><?= $escape($institution['name']); ?></h3><span class="ownership-badge <?= $institution['ownership'] === 'Government' ? 'government' : 'private'; ?>"><?= $escape($institution['ownership']); ?></span></div><p class="meta"><span aria-hidden="true">⌖</span> <?= $escape($institution['city']); ?></p><p class="institution-description"><?= $escape($institution['description'] ?: 'Description not provided.'); ?></p><div class="institution-details-row"><span><strong>Fee range</strong><?= $escape($institution['fee_range'] ?: 'Not available'); ?></span><?php if ($website !== null): ?><a href="<?= $escape($website); ?>" target="_blank" rel="noopener noreferrer">Official website ↗</a><?php else: ?><span class="muted-fact">Website unverified</span><?php endif; ?></div>
                                    <label class="compare-checkbox"><input type="checkbox" name="compare[]" value="<?= (int) $institution['id']; ?>" data-compare-check <?= $isSelected ? 'checked' : ''; ?>><span><?= $isSelected ? 'Selected for comparison' : 'Add to compare'; ?></span></label>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                    <div class="catalogue-bottom"><p>Select up to three institutions to compare the information available in our database.</p><button type="submit" class="primary-btn">View comparison →</button></div>
                </form>
            <?php endif; ?>
            <p class="demo-data-note final-data-note">Data completeness varies by institution. Fee ranges and other details should be confirmed with official sources.</p>
        </section>

        <section class="section-block faq-section" id="faqs">
            <div class="section-heading"><div><p class="eyebrow">Here to help</p><h2>Frequently asked questions</h2></div></div>
            <div class="faq-list">
                <details><summary>What is EduTricity?</summary><p>EduTricity helps students discover and compare educational institutions across Chandigarh, Mohali, and Panchkula.</p></details>
                <details><summary>Which areas are covered?</summary><p>The initial scope includes Chandigarh, Mohali (SAS Nagar), and Panchkula.</p></details>
                <details><summary>Which institution types can I explore?</summary><p>The catalogue supports schools, colleges, universities, coaching centres, and skill-development institutes where records are available.</p></details>
                <details><summary>How does institution comparison work?</summary><p>Select up to three institutions and use Compare Selected. The table displays fields present in the database and marks missing information as unavailable.</p></details>
                <details><summary>Can I suggest an institution?</summary><p>Yes. Use the suggestion form below. Submissions are stored for review and are not automatically treated as verified records.</p></details>
            </div>
        </section>

        <section class="suggestion-panel section-block" id="suggest">
            <div class="panel-heading"><div><p class="eyebrow">Contribute to the directory</p><h2>Suggest an Institution</h2><p>Help us discover institutions that are missing from the catalogue.</p></div></div>
            <?php if ($showSuccess): ?><div class="flash success" role="status">Your suggestion was submitted successfully and is awaiting review.</div><?php endif; ?>
            <?php if ($showError): ?><div class="flash error" role="alert">We couldn't submit the suggestion. Check the required fields and try again.</div><?php endif; ?>
            <form id="suggest-form" method="post" action="/process-suggestion.php" class="suggest-form">
                <input type="hidden" name="csrf_token" value="<?= $escape($csrfToken); ?>">
                <div class="honeypot" aria-hidden="true"><label>Leave this field empty<input type="text" name="website_url" tabindex="-1" autocomplete="off"></label></div>
                <div class="field-row"><label>Institution name<input type="text" name="institution" maxlength="255" placeholder="Enter institution name" required></label><label>Location<input type="text" name="location" maxlength="150" placeholder="Chandigarh, Mohali, Panchkula" required></label></div>
                <label>Additional details <span class="optional-label">(optional)</span><textarea name="details" rows="4" maxlength="2000" placeholder="Institution type, official website, courses, or other useful information"></textarea></label>
                <div class="form-submit-row"><p class="form-note">Submissions are reviewed before being added to the catalogue.</p><button class="primary-btn" type="submit">Submit suggestion ↗</button></div>
            </form>
        </section>

        <section class="about-strip" id="about"><span class="about-mark" aria-hidden="true">✦</span><div><p class="eyebrow">About EduTricity</p><h2>Explore your next opportunity.</h2><p>Bringing education discovery and comparison into one place for Chandigarh, Mohali, and Panchkula.</p></div><a href="#top" class="back-top">Back to top ↑</a></section>
    </main>
</div>
<div class="toast" id="site-toast" role="status" aria-live="polite"></div>
<?php renderFooter(); ?>
