<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../app/db.php';

$redirectWithStatus = static function (string $status): never {
    header('Location: /index.php?' . http_build_query([$status => '1']) . '#suggest', true, 303);
    exit;
};

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /index.php#suggest', true, 303);
    exit;
}

// Quietly reject common bot submissions via the hidden honeypot field.
if (trim((string) ($_POST['website_url'] ?? '')) !== '') {
    $redirectWithStatus('success');
}

$institution = trim((string) ($_POST['institution'] ?? ''));
$location = trim((string) ($_POST['location'] ?? ''));
$details = trim((string) ($_POST['details'] ?? ''));
$providedToken = (string) ($_POST['csrf_token'] ?? '');
$sessionToken = (string) ($_SESSION['edutricity_csrf_token'] ?? '');

if ($sessionToken === '' || $providedToken === '' || !hash_equals($sessionToken, $providedToken)) {
    $redirectWithStatus('error');
}

if ($institution === '' || $location === '' || strlen($institution) > 255 || strlen($location) > 150 || strlen($details) > 2000) {
    $redirectWithStatus('error');
}

try {
    $pdo = getDbConnection();
    $stmt = $pdo->prepare(
        "INSERT INTO suggestions (institution_name, location, details, status)
         VALUES (:institution, :location, :details, 'pending')"
    );
    $stmt->execute([
        ':institution' => $institution,
        ':location' => $location,
        ':details' => $details === '' ? null : $details,
    ]);
    $redirectWithStatus('success');
} catch (Throwable $e) {
    error_log('EduTricity suggestion submission error: ' . $e->getMessage());
    $redirectWithStatus('error');
}
