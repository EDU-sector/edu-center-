<?php
function renderFooter(): void
{
    ?>
    <footer class="site-footer">
        <a class="footer-brand" href="/index.php">EduTricity</a>
        <p>Education discovery for Chandigarh, Mohali, and Panchkula.</p>
        <a href="#top">Back to top ↑</a>
        <small>Institution details may change. Confirm critical information with official sources.</small>
    </footer>
    </body>
    </html>
    <?php
}
