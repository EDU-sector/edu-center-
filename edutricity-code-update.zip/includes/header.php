<?php
function renderHeader(string $title = 'EduTricity', int $comparisonCount = 0): void
{
    $escapeHeader = static fn ($value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $currentCity = is_string($_GET['city'] ?? null) ? $_GET['city'] : '';
    $searchValue = is_string($_GET['q'] ?? null) ? $_GET['q'] : '';
    $documentRoot = rtrim((string) ($_SERVER['DOCUMENT_ROOT'] ?? ''), DIRECTORY_SEPARATOR);
    $assetBase = is_file($documentRoot . '/assets/css/style.css') ? '/assets' : '/public/assets';
    ?>
    <!doctype html>
    <html lang="en" data-theme="light">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="theme-color" content="#f7faff">
        <meta name="description" content="Discover and compare educational institutions across Chandigarh, Mohali, and Panchkula with EduTricity.">
        <title><?= $escapeHeader($title); ?></title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="<?= $escapeHeader($assetBase); ?>/css/style.css">
        <script src="<?= $escapeHeader($assetBase); ?>/js/app.js" defer></script>
    </head>
    <body>
        <header class="topbar">
            <a class="brand-wrap" href="/index.php" aria-label="EduTricity home">
                <span class="brand-symbol" aria-hidden="true">
                    <svg viewBox="0 0 48 48" role="presentation"><path d="M3 15.5 24 5l21 10.5L24 26 3 15.5Z" fill="currentColor"/><path d="M11 21.2v9.2c7.4 6.7 18.6 6.7 26 0v-9.2L24 28 11 21.2Z" fill="currentColor"/><path d="M43 17v12" stroke="currentColor" stroke-width="3.5" stroke-linecap="round"/><circle cx="43" cy="32" r="3" fill="currentColor"/></svg>
                </span>
                <span class="brand-copy"><strong>EduTricity</strong><small>Chandigarh · Mohali · Panchkula</small></span>
            </a>

            <form class="top-search" method="get" action="/index.php#institutions" role="search">
                <span aria-hidden="true" class="search-icon">⌕</span>
                <label class="sr-only" for="top-search-q">Search institutions, courses, exams, locations</label>
                <input id="top-search-q" type="search" name="q" value="<?= $escapeHeader($searchValue); ?>" placeholder="Search institutions, categories, locations...">
                <button type="submit" aria-label="Search">Search</button>
            </form>

            <nav class="top-locations" aria-label="Choose a location">
                <?php foreach (['Chandigarh', 'Mohali', 'Panchkula'] as $city): ?>
                    <?php $query = $_GET; $query['city'] = $city; unset($query['success'], $query['error']); ?>
                    <a class="location-chip <?= ($currentCity === $city || ($currentCity === '' && $city === 'Chandigarh')) ? 'active' : ''; ?>" href="/index.php?<?= $escapeHeader(http_build_query($query)); ?>#institutions"><span aria-hidden="true">⌖</span><?= $escapeHeader($city); ?></a>
                <?php endforeach; ?>
            </nav>

            <div class="header-actions">
                <button type="button" class="theme-toggle" aria-label="Switch to dark mode" title="Toggle colour theme"><span class="theme-toggle-icon" aria-hidden="true">☼</span></button>
                <span class="header-divider" aria-hidden="true"></span>
                <button type="button" class="sign-in-button" id="sign-in-button"><span aria-hidden="true">♙</span> Sign In</button>
            </div>
        </header>
    <?php
}
